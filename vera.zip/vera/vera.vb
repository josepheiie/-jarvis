﻿Imports System.Speech
Imports System.Speech.Recognition
Imports System.Runtime.InteropServices
Imports System.IO
Imports System.Net

Public Class Form1
    Dim WithEvents reco As New Recognition.SpeechRecognitionEngine

    Dim commandset() As String
    Dim cmdList As New GrammarBuilder

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim npath As String = Application.StartupPath & "\commandlist.txt"
        Dim nsr As StreamReader = File.OpenText(npath)
        Dim i As Integer
        Dim ls As String
        For Each ls In File.ReadLines(npath)
            ReDim Preserve commandset(i)
            commandset(i) = ls
            i += 1
            ListBox1.Items.Add(ls)
            Application.DoEvents()
        Next

        reco.SetInputToDefaultAudioDevice()

        cmdList.Append(New Choices(commandset))
        reco.LoadGrammar(New Recognition.Grammar(cmdList))
        reco.RecognizeAsync()
    End Sub

    Private Sub reco_RecognizeCompleted(ByVal sender As Object, ByVal e As System.Speech.Recognition.RecognizeCompletedEventArgs) Handles reco.RecognizeCompleted

        reco.RecognizeAsync()
    End Sub

    Public Function getrandom(ByVal min As Integer, ByVal max As Integer) As Integer
        Static generator As System.Random = New System.Random()
        Return generator.Next(min, max)
    End Function

    Private Sub reco_SpeechRecognized(ByVal sender As Object, ByVal e As System.Speech.Recognition.RecognitionEventArgs) Handles reco.SpeechRecognized
        Dim response As String = ""
        Dim synth As New Synthesis.SpeechSynthesizer
        Dim npath As String = Application.StartupPath & "\commandactionlist.txt"
        Dim nsr As StreamReader = File.OpenText(npath)
        Dim ls As String



        Dim params(3) As String
        Dim execute = e.Result.Text.ToLower
        Dim answer As String = ""
        For Each ls In File.ReadLines(npath)

            Dim value As Integer = getrandom(0, 6)
            params = ls.Split("^"c)
            Dim Command As String = params(0).ToLower
            Dim comtype As String = params(2)
            If comtype = "social" Then

                If value <= 3 Then
                    response = params(1)
                ElseIf value > 3 Then
                    response = params(3)
                End If

            Else
                response = params(1)

            End If
            Dim Action As String = response


            If execute.Contains(Command) And comtype = "social" Then
                Dim robotvoice = CreateObject("sapi.spvoice")
                answer = Action
                robotvoice.Speak(answer)

            ElseIf execute.Contains(Command) And comtype = "comando" Then
                Dim robotvoice = CreateObject("sapi.spvoice")

                If execute.Contains("open") Then
                    answer = "Opening application"
                    robotvoice.Speak(answer)
                    Process.Start(Action)
                ElseIf execute.Contains("close") Then
                    answer = "Closing application"
                    robotvoice.Speak(answer)
                    For Each myprocess As Process In Process.GetProcessesByName(Action)
                        myprocess.CloseMainWindow()
                    Next

                ElseIf execute.Contains(Command) And comtype = "website" Then

                    Try
                        If My.Computer.Network.IsAvailable = True Then

                            answer = "Website is opening in a while"
                            robotvoice.Speak(answer)
                            Process.Start(Action)

                        Else

                            answer = "It looks like there is no Internet connection available"
                            robotvoice.Speak(answer)
                        End If
                    Catch ex As Exception

                    End Try

                End If


            ElseIf execute.Contains(Command) And comtype = "internal" Then
                Dim robotvoice = CreateObject("sapi.spvoice")
                answer = "Ok Creator"
                robotvoice.Speak(answer)
                If Command = "show commands" Then
                    ListBox1.Visible = True

                ElseIf execute.Contains("goodbye") Then
                    answer = Action
                    robotvoice.Speak(answer)
                    reco.UnloadAllGrammars()
                    reco.RecognizeAsyncStop()
                    reco.Dispose()

                    Me.Close()


                ElseIf Command = "hide commands" Then
                    ListBox1.Visible = False


                ElseIf Command = "go full screen" Then
                    Me.WindowState = FormWindowState.Maximized


                End If
                Application.DoEvents()
            End If

        Next

    End Sub


End Class

